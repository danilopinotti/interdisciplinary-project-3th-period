<meta charset="UTF-8">
<?php

	if (!$link = mysql_connect('localhost', 'root', 'root')) {
	    echo 'Não foi possível conectar ao mysql';
	    exit;
	}

	if (!mysql_select_db('projeto_integrador', $link)) {
	    echo 'Não foi possível selecionar o banco de dados';
	    exit;
	}

	//$sql    = 'SELECT * FROM city';
	//$result = mysql_query($sql, $link);


	$nomes_m = ['Davi', 'Arthur', 'Pedro', 'Gabriel', 'Bernardo', 'Lucas', 'Matheus', 'Rafael', 'Heitor', 'Enzo', 'Guilherme', 'Nicolas', 'Lorenzo', 'Gustavo', 'Felipe', 'Samuel', 'João Pedro', 'Daniel', 'Vitor', 'Leonardo', 'Henrique', 'Theo', 'Murilo', 'Eduardo', 'Pietro', 'Cauã', 'Isaac', 'Caio', 'Vinicius', 'Benjamin', 'João', 'Lucca', 'João Miguel', 'Bryan', 'Joaquim', 'Joãoitor', 'Thiago', 'Antônio', 'Davi Lucas', 'Francisco', 'Enzo Gabriel', 'Bruno', 'Emanuel', 'João Gabriel', 'Ian', 'Davi Luiz', 'Rodrigo', 'Otávio'];
	$nomes_f = ['Alice','Julia','Isabella','Manuela','Laura','Luiza','Valentina','Giovanna','Maria Eduarda','Helena','Beatriz','Maria Luiza','Lara','Mariana','Nicole','Rafaela','Heloísa','Isadora','Lívia','Maria Clara','Ana Clara'];
	
	$sobrenomes = ['Silva','Souza','Costa','Santos','Oliveira','Pereira','Rodrigues','Almeida','Nascimento','Lima','Araújo','Fernandes','Carvalho','Gomes','Martins','Rocha','Ribeiro','Alves','Monteiro','Mendes','Barros','Freitas','Barbosa','Pinto','Moura','Cavalcanti','Dias','Castro','Campos','Cardoso'];

	$ruas = ['Rua Dois','Rua Três','Rua Um','Rua B','Rua Quatro','Rua Principal','Rua A','Rua C','Rua Cinco','Rua Seis','Rua D','Rua Sete','Rua Oito','Rua E','Rua F','Rua Nove','Rua Dez','Rua G','Rua São José','Rua Onze','Rua H','Rua São Paulo','Rua Doze','Rua Treze','Rua Santo Antônio','Avenida Brasil','Rua I','Rua 2','Rua 1','Rua 3','Rua Sao Pedro','Rua Quinze','Rua Sao João','Rua J','Rua Quatorze','Rua Sao Francisco','Rua Sete de Setembro','Rua 4','Rua Dezesseis','Rua Quinze De Novembro','Rua 5','Rua Tiradentes','Rua Dezessete','Rua 6','Rua L','Rua Vinte','Rua Bahia','Rua Amazonas','Rua Dezoito','Rua Sao Sebastiao','Rua Parana','Rua Bela Vista','Rua M','Rua 7','Rua Santa Luzia','Rua Sao Jorge','Rua Dezenove','Rua Castro Alves','Rua Duque De Caxias','Rua Projetada','Rua Rui Barbosa','Rua Santa Catarina','Rua Minas Gerais','Rua N','Rua Santos Dumont','Rua 8','Rua Espirito Santo','Rua Vinte','Rua Vinte e Dois','Rua Da Paz','Rua Treze De Maio','Rua K','Rua Rio De Janeiro','Rua Goias','Rua Ceara','Rua 10','Rua Belo Horizonte','Rua Das Flores','Rua Sergipe','Rua Vitoria','Rua José Bonifácio','Rua Pernambuco','Rua Piauí','Rua Vinte e Três','Rua 9','Rua Mato Grosso','Rua Santa Maria','Rua Dom Pedro II','Rua Primeiro de Maio','Rua Pará','Rua Maranhão','Rua Alagoas','Rua Boa Vista','Rua Sao Luiz','Rua Vinte e Quatro','Rua Paraíba','Rua 12','Rua O','Rua Santa Rita','Rua 11'];

	$servidores_emails = ['@hotmail.com','@gmail.com','@yahoo.com.br','@bol.com.br','@outlook.com'];

	//
	for ($i = 0; $i<15;$i++){
		$genre = rand (0,1);
		if ($genre) 
			$name = $nomes_m[rand(0,sizeof($nomes_m)-1)];
		else
			$name = $nomes_f[rand(0,sizeof($nomes_f)-1)];

		$name .= " ".$sobrenomes[rand(0,sizeof($sobrenomes)-1)];

		$address = $ruas[rand(0,sizeof($ruas)-1)].', '.rand(0,1000);

		$email = strtolower(str_replace(" ","",$name)).rand(0,27).$servidores_emails[rand(0,sizeof($servidores_emails)-1)];

		$phone = (string)(rand(11111111111,99999999999));

		$id_cidade = rand(1,6);
		
		$document_type = rand(0,1);
		if ($document_type)
			$document = rand(11111111111,99999999999);
		else
			$document = rand(11111111111111,99999999999999);

		$sql = "INSERT INTO client VALUES (NULL,'".$name."','".$address."',".$genre.",'".$email."','".$phone."',".$id_cidade."','".$document.",'".$document_type."');";

		echo $sql . '<br>';


		mysql_query($sql, $link);
	}
	echo 'done';
	//mysql_free_result($result);

?>