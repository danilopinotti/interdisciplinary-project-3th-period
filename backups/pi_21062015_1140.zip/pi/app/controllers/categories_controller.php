<?php
class CategoriesController extends ApplicationController {

   protected $beforeAction = array('authenticated' => 'all');

   public function index() {
      $this->categories = $this->pagination('Category', array('url' => '/categorias', 'limit' => 10));
   }

   public function _new() {
     $this->category = new Category();
     $this->submit = 'Nova categoria';
     $this->action = $this->urlFor('/categorias');
   }

   public function create() {
    $this->category = new Category($this->params['category']);

    if ($this->category->save()) {
       Flash::message('success', 'Registro realizado com sucesso!');
       $this->redirectTo('/categorias');
    }else{
       Flash::message('danger', 'Existe dados incorretos no seu formulário!');
       $this->submit = 'Nova categoria';
       $this->action = $this->urlFor("/categorias");
       $this->render('new');
     }
   }

   public function edit() {
     $this->category = Category::findById($this->params[':id']);
     $this->submit = 'Salvar';
     $this->action = $this->urlFor("/categorias/{$this->category->getId()}");
   }


   public function update() {
     $this->category = Category::findById($this->params[':id']);

     if ($this->category->update($this->params['category'])) {
       Flash::message('success', 'Registro atualizado com sucesso!');
       $this->redirectTo('/categorias');
     } else {
       Flash::message('danger', 'Existe dados incorretos no seu formulário!');
       $this->submit = 'Salvar';
       $this->action = $this->urlFor("/categorias/{$this->category->getId()}");
       $this->render('edit');
     }
   }

  public function destroy() {
    $category = Category::findById($this->params[':id']);
    $category->delete();
    Flash::message('success', 'Categoria removida com sucesso!');
    $this->redirectTo("/categorias");
  }
} ?>
