-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 04/06/2015 às 14:10
-- Versão do servidor: 5.5.43-0ubuntu0.14.04.1
-- Versão do PHP: 5.5.9-1ubuntu4.9

/* scripts para criação do banco de dados */
DROP DATABASE IF EXISTS projeto_integrador;

CREATE DATABASE projeto_integrador;

USE projeto_integrador;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `projeto_integrador`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Fazendo dump de dados para tabela `categories`
--

INSERT INTO `categories` (`id`, `description`) VALUES
(1, 'formatação'),
(2, 'formatação com backup'),
(3, 'manutenção em monitores'),
(4, 'manutenção em notebooks'),
(5, 'manutenção em componentes de hardware'),
(6, 'manutenção de perifericos'),
(7, 'manutenção em impressoras'),
(8, 'configuração de modem'),
(9, 'configuração e manutenção de servidores'),
(10, 'configuração de estação e usuário'),
(11, 'instalação de programas'),
(12, 'instalação e configuração de redes'),
(13, 'instalação de rede sem fio'),
(14, 'troca de peças'),
(15, 'remoção de vírus e spywares'),
(16, 'montagem de computadores'),
(17, 'recuperação de dados'),
(18, 'administração e configuração de firewall'),
(19, 'limpeza de computadores'),
(20, 'otimização do sistema'),
(21, 'formatação'),
(22, 'formatação com backup'),
(23, 'manutenção em monitores'),
(24, 'manutenção em notebooks'),
(25, 'manutenção em componentes de hardware'),
(26, 'manutenção de perifericos'),
(27, 'manutenção em impressoras'),
(28, 'configuração de modem'),
(29, 'configuração e manutenção de servidores'),
(30, 'configuração de estação e usuário'),
(31, 'instalação de programas'),
(32, 'instalação e configuração de redes'),
(33, 'instalação de rede sem fio'),
(34, 'troca de peças'),
(35, 'remoção de vírus e spywares'),
(36, 'montagem de computadores'),
(37, 'recuperação de dados'),
(38, 'administração e configuração de firewall'),
(39, 'limpeza de computadores'),
(40, 'otimização do sistema');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `states_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_cities_states` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Fazendo dump de dados para tabela `cities`
--

INSERT INTO `cities` (`id`, `name`, `states_id`) VALUES
(1, 'Guarapuava', 16),
(2, 'Londrina', 16),
(3, 'Dracena', 25),
(4, 'São Paulo', 25),
(5, 'Concórdia', 24),
(6, 'Florianópolis', 24);

-- --------------------------------------------------------

--
-- Estrutura para tabela `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(70) NOT NULL,
  `genre` char(1) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `phone` varchar(11) NOT NULL,
  `client_type` tinyint(1) NOT NULL,
  `cities_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_clients_cities` (`cities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `genre` char(1) NOT NULL,
  `date_contratation` date NOT NULL,
  `date_exit` date DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `last_access` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `items_service_order`
--

CREATE TABLE IF NOT EXISTS `items_service_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cost` float DEFAULT NULL,
  `service_orders_id` int(11) NOT NULL,
  `services_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_items_service_order_services` (`services_id`),
  KEY `FK_items_service_order_service_orders` (`service_orders_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `juridical_clients`
--

CREATE TABLE IF NOT EXISTS `juridical_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cnpj` int(14) NOT NULL,
  `fantasy_name` varchar(50) NOT NULL,
  `clients_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_juridical_clients_clients` (`clients_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `physical_clients`
--

CREATE TABLE IF NOT EXISTS `physical_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` int(11) NOT NULL,
  `home_phone` varchar(11) NOT NULL,
  `clients_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_physical_clients_clients` (`clients_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `priorities`
--

CREATE TABLE IF NOT EXISTS `priorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Fazendo dump de dados para tabela `priorities`
--

INSERT INTO `priorities` (`id`, `name`) VALUES
(1, 'alta'),
(2, 'media'),
(3, 'baixa'),
(4, 'baixa'),
(5, 'alta'),
(6, 'baixa'),
(7, 'media'),
(8, 'alta'),
(9, 'alta'),
(10, 'media'),
(11, 'alta'),
(12, 'baixa'),
(13, 'baixa'),
(14, 'media'),
(15, 'media'),
(16, 'baixa'),
(17, 'alta'),
(18, 'alta'),
(19, 'baixa'),
(20, 'alta'),
(21, 'baixa'),
(22, 'alta'),
(23, 'baixa'),
(24, 'alta'),
(25, 'media'),
(26, 'alta'),
(27, 'baixa'),
(28, 'media'),
(29, 'media'),
(30, 'alta'),
(31, 'media'),
(32, 'alta'),
(33, 'baixa'),
(34, 'alta'),
(35, 'baixa'),
(36, 'baixa'),
(37, 'alta'),
(38, 'alta'),
(39, 'baixa'),
(40, 'media'),
(41, 'alta'),
(42, 'baixa'),
(43, 'baixa'),
(44, 'alta'),
(45, 'media'),
(46, 'alta'),
(47, 'alta'),
(48, 'media'),
(49, 'baixa'),
(50, 'media'),
(51, 'alta'),
(52, 'baixa');

-- --------------------------------------------------------

--
-- Estrutura para tabela `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `cost` float NOT NULL,
  `categories_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_services_categories` (`categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `service_orders`
--

CREATE TABLE IF NOT EXISTS `service_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priorities_id` int(1) NOT NULL,
  `situations_id` int(1) NOT NULL,
  `opening_date` datetime NOT NULL,
  `prevision` datetime NOT NULL,
  `total_cost` float NOT NULL,
  `reported_problem` varchar(150) NOT NULL,
  `observation` varchar(150) DEFAULT NULL,
  `employees_id` int(11) NOT NULL,
  `clients_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_service_orders_clients` (`clients_id`),
  KEY `FK_service_orders_priorities` (`priorities_id`),
  KEY `FK_service_orders_situations` (`situations_id`),
  KEY `FK_service_orders_employees` (`employees_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `service_orders_situation`
--

CREATE TABLE IF NOT EXISTS `service_orders_situation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_orders_id` int(11) NOT NULL,
  `previous_situations_id` int(11) NOT NULL,
  `actual_situations_id` int(11) NOT NULL,
  `modification_date` datetime NOT NULL,
  `employees_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_service_orders_situation_employees` (`employees_id`),
  KEY `FK_service_orders_situation_service_orders` (`service_orders_id`),
  KEY `FK_service_orders_situation_previous_situations` (`previous_situations_id`),
  KEY `FK_service_orders_situation_actual_situations` (`actual_situations_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `situations`
--

CREATE TABLE IF NOT EXISTS `situations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Fazendo dump de dados para tabela `situations`
--

INSERT INTO `situations` (`id`, `name`) VALUES
(1, 'em aberto'),
(2, 'cancelada'),
(3, 'concluída'),
(4, 'concluída'),
(5, 'aprovada'),
(6, 'concluída'),
(7, 'cancelada'),
(8, 'concluída'),
(9, 'em aberto'),
(10, 'aprovada'),
(11, 'em aberto'),
(12, 'em aberto'),
(13, 'concluída'),
(14, 'em aberto'),
(15, 'em aberto'),
(16, 'aprovada'),
(17, 'aprovada'),
(18, 'reprovada'),
(19, 'aprovada'),
(20, 'aprovada'),
(21, 'aprovada'),
(22, 'cancelada'),
(23, 'aprovada'),
(24, 'aprovada'),
(25, 'aprovada'),
(26, 'concluída'),
(27, 'concluída'),
(28, 'aprovada'),
(29, 'aprovada'),
(30, 'aprovada'),
(31, 'aprovada'),
(32, 'concluída'),
(33, 'concluída'),
(34, 'concluída'),
(35, 'concluída'),
(36, 'concluída'),
(37, 'aprovada'),
(38, 'concluída'),
(39, 'concluída'),
(40, 'concluída'),
(41, 'concluída'),
(42, 'em aberto'),
(43, 'concluída'),
(44, 'reprovada'),
(45, 'concluída'),
(46, 'em aberto'),
(47, 'concluída'),
(48, 'em aberto'),
(49, 'concluída'),
(50, 'cancelada'),
(51, 'em aberto'),
(52, 'cancelada');

-- --------------------------------------------------------

--
-- Estrutura para tabela `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acronym` char(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Fazendo dump de dados para tabela `states`
--

INSERT INTO `states` (`id`, `acronym`) VALUES
(1, 'AC'),
(2, 'AL'),
(3, 'AP'),
(4, 'AM'),
(5, 'BA'),
(6, 'CE'),
(7, 'DF'),
(8, 'ES'),
(9, 'GO'),
(10, 'MA'),
(11, 'MT'),
(12, 'MS'),
(13, 'MG'),
(14, 'PA'),
(15, 'PB'),
(16, 'PR'),
(17, 'PE'),
(18, 'PI'),
(19, 'RJ'),
(20, 'RN'),
(21, 'RS'),
(22, 'RO'),
(23, 'RR'),
(24, 'SC'),
(25, 'SP'),
(26, 'SE'),
(27, 'TO');

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `FK_cities_states` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`);

--
-- Restrições para tabelas `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `FK_clients_cities` FOREIGN KEY (`cities_id`) REFERENCES `cities` (`id`);

--
-- Restrições para tabelas `items_service_order`
--
ALTER TABLE `items_service_order`
  ADD CONSTRAINT `FK_items_service_order_services` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`),
  ADD CONSTRAINT `FK_items_service_order_service_orders` FOREIGN KEY (`service_orders_id`) REFERENCES `service_orders` (`id`);

--
-- Restrições para tabelas `juridical_clients`
--
ALTER TABLE `juridical_clients`
  ADD CONSTRAINT `FK_juridical_clients_clients` FOREIGN KEY (`clients_id`) REFERENCES `clients` (`id`);

--
-- Restrições para tabelas `physical_clients`
--
ALTER TABLE `physical_clients`
  ADD CONSTRAINT `FK_physical_clients_clients` FOREIGN KEY (`clients_id`) REFERENCES `clients` (`id`);

--
-- Restrições para tabelas `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `FK_services_categories` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`);

--
-- Restrições para tabelas `service_orders`
--
ALTER TABLE `service_orders`
  ADD CONSTRAINT `FK_service_orders_clients` FOREIGN KEY (`clients_id`) REFERENCES `clients` (`id`),
  ADD CONSTRAINT `FK_service_orders_employees` FOREIGN KEY (`employees_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `FK_service_orders_priorities` FOREIGN KEY (`priorities_id`) REFERENCES `priorities` (`id`),
  ADD CONSTRAINT `FK_service_orders_situations` FOREIGN KEY (`situations_id`) REFERENCES `situations` (`id`);

--
-- Restrições para tabelas `service_orders_situation`
--
ALTER TABLE `service_orders_situation`
  ADD CONSTRAINT `FK_service_orders_situation_actual_situations` FOREIGN KEY (`actual_situations_id`) REFERENCES `situations` (`id`),
  ADD CONSTRAINT `FK_service_orders_situation_employees` FOREIGN KEY (`employees_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `FK_service_orders_situation_previous_situations` FOREIGN KEY (`previous_situations_id`) REFERENCES `situations` (`id`),
  ADD CONSTRAINT `FK_service_orders_situation_service_orders` FOREIGN KEY (`service_orders_id`) REFERENCES `service_orders` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
