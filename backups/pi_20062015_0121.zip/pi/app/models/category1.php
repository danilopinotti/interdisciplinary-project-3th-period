<?php
class Category extends Base {

    private $name;

    public function setName($name) {
      $this->name = $name;
    }

    public function getName() {
      return $this->name;
    }

    public function validates() {
      Validations::notEmpty($this->name, 'name', $this->errors);
      Validations::uniqueField($this->name, 'name', 'categories', $this->errors);
    }

    public function save() {
      if (!$this->isvalid()) return false;
      $params = array($this->name, $this->createdAt);
      $sql = "insert into categories (name, created_at) 
                            values (?,?)";

      $db = Database::getConnection();
      $statement = $db->prepare($sql);
      $resp = $statement->execute($params);

      if (!$resp) {
         Logger::getInstance()->log("Falha para salvar: " . print_r($this, TRUE), Logger::ERROR);
         Logger::getInstance()->log("Error: " . print_r(error_get_last(), true), Logger::ERROR);
         return false;
      }
      return true;
    }

    public function update($data = array()) {
      $this->setData($data);
      if (!$this->isvalid()) return false;

      $params = array($this->name, $this->id);
      $sql = "update categories set name=?
              where id = ?";

      $db = Database::getConnection();
      $statement = $db->prepare($sql);
      $resp = $statement->execute($params);

      if (!$resp) {
         Logger::getInstance()->log("Falha para atualizar: " . print_r($this, TRUE), Logger::ERROR);
         Logger::getInstance()->log("Error: " . print_r(error_get_last(), true), Logger::ERROR);
         return false;
      }
      return true;
    }

    public function delete() {
      $db = Database::getConnection();
      $params = array($this->id);
      $sql = "delete from categories where id = ?";
      $statement = $db->prepare($sql);
      return $statement->execute($params);
    }

    public static function all($options = null) {
      $db = Database::getConnection();

      if ($options !== null) {
        $limit = $options['limit'] ;
        $offset = ($options['page'] - 1) * $limit;

        $sql = "SELECT * FROM categories ORDER BY created_at DESC LIMIT :limit
                OFFSET :offset";
 
        $statement = $db->prepare($sql);
        $statement->bindParam(':limit', $limit, PDO::PARAM_INT);
        $statement->bindParam(':offset', $offset, PDO::PARAM_INT);
      } else {
        $sql = "SELECT * FROM categories ORDER BY created_at DESC";
        $statement = $db->prepare($sql);
      }

      $resp = $statement->execute();

      $categories = array();
      while ($resp && $row = $statement->fetch(PDO::FETCH_ASSOC)) {
        $categories[] = new Category($row);
      }

      return $categories;
    }

    public static function findById($id) {
      $sql = "select * from categories where id = ?";
      $params = array($id);

      $db = Database::getConnection();
      $statement = $db->prepare($sql);
      $resp = $statement->execute($params);

      if ($resp && $row = $statement->fetch(PDO::FETCH_ASSOC)) {
        return new Category($row);
      }

      return null;
    }

    public static function count() {
      $sql = "SELECT COUNT(*) FROM categories";

      $db = Database::getConnection();
      $statement = $db->prepare($sql);
      $statement->execute();

      return $statement->fetch()[0];
    }
} ?>

