<?php class ApplicationController extends BaseController {

}
