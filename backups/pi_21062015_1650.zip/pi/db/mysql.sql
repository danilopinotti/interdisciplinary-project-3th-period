-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 04/06/2015 às 14:10
-- Versão do servidor: 5.5.43-0ubuntu0.14.04.1
-- Versão do PHP: 5.5.9-1ubuntu4.9

/* scripts para criação do banco de dados */
DROP DATABASE IF EXISTS projeto_integrador;

CREATE DATABASE projeto_integrador;

USE projeto_integrador;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `projeto_integrador`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `categories`
--

INSERT INTO `categories` (`id`, `description`) VALUES
(1, 'Manutenção Física'),
(2, 'Manutenção Lógica'),
(3, 'Redes'),
(4, 'Otimização do sistema'),
(5, 'Periféricos');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `states_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `cities`
--

INSERT INTO `cities` (`id`, `name`, `states_id`) VALUES
(1, 'Guarapuava', 16),
(2, 'Londrina', 16),
(3, 'Dracena', 25),
(4, 'São Paulo', 25),
(5, 'Concórdia', 24),
(6, 'Florianópolis', 24);

-- --------------------------------------------------------

--
-- Estrutura para tabela `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(70) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `phone` varchar(11) NOT NULL,
  `client_type` char(1) NOT NULL,
  `cities_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `clients`
--

INSERT INTO `clients` (`id`, `name`, `address`, `email`, `phone`, `client_type`, `cities_id`) VALUES
(4, 'Danilo Augusto Pinotti de Mello', 'Rua Marechal Rondon, 60', 'danilopinotti@hotmail.com', '18997096654', 'F', 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `genre` char(1) NOT NULL,
  `date_contratation` date NOT NULL,
  `date_exit` date DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `last_access` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `phone`, `genre`, `date_contratation`, `date_exit`, `password`, `last_access`) VALUES
(1, 'Pedro da Silva', 'admin@admin.com', '4236243624', 'M', '2012-07-20', '2014-02-14', 'd033e22ae348aeb5660fc2140aec35850c4da997', '2015-06-07 00:00:00'),
(2, 'João Cardoso', 'joao@gmail.com', '1234123', 'M', '2015-06-17', NULL, '12345', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `items_service_order`
--

CREATE TABLE IF NOT EXISTS `items_service_order` (
`id` int(11) NOT NULL,
  `cost` float DEFAULT NULL,
  `service_orders_id` int(11) NOT NULL,
  `services_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `items_service_order`
--

INSERT INTO `items_service_order` (`id`, `cost`, `service_orders_id`, `services_id`) VALUES
(7, 50, 9, 1),
(8, 450, 9, 2),
(9, 50, 10, 1),
(10, 50, 13, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `juridical_clients`
--

CREATE TABLE IF NOT EXISTS `juridical_clients` (
`id` int(11) NOT NULL,
  `cnpj` char(14) NOT NULL,
  `clients_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `physical_clients`
--

CREATE TABLE IF NOT EXISTS `physical_clients` (
`id` int(11) NOT NULL,
  `genre` char(1) DEFAULT NULL,
  `cpf` char(11) NOT NULL,
  `clients_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `physical_clients`
--

INSERT INTO `physical_clients` (`id`, `genre`, `cpf`, `clients_id`) VALUES
(3, 'M', '42532770805', 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `priorities`
--

CREATE TABLE IF NOT EXISTS `priorities` (
`id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `priorities`
--

INSERT INTO `priorities` (`id`, `name`) VALUES
(2, 'Alta'),
(3, 'Normal'),
(4, 'Baixa');

-- --------------------------------------------------------

--
-- Estrutura para tabela `services`
--

CREATE TABLE IF NOT EXISTS `services` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `cost` float NOT NULL,
  `categories_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `services`
--

INSERT INTO `services` (`id`, `name`, `description`, `cost`, `categories_id`) VALUES
(1, 'Formatação simples sem ativação', 'Formatação simples sem backup com Windows 7 não ativado', 50, 2),
(2, 'Formatação simples com ativação', 'Formatação simples sem backup com Windows 7 ativado', 450, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `service_orders`
--

CREATE TABLE IF NOT EXISTS `service_orders` (
`id` int(11) NOT NULL,
  `priorities_id` int(1) NOT NULL,
  `situations_id` int(1) NOT NULL,
  `opening_date` datetime NOT NULL,
  `prevision` date NOT NULL,
  `total_cost` float NOT NULL,
  `reported_problem` varchar(150) NOT NULL,
  `observation` varchar(150) DEFAULT NULL,
  `employees_id` int(11) NOT NULL,
  `clients_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `service_orders`
--

INSERT INTO `service_orders` (`id`, `priorities_id`, `situations_id`, `opening_date`, `prevision`, `total_cost`, `reported_problem`, `observation`, `employees_id`, `clients_id`) VALUES
(9, 2, 4, '2015-06-20 01:21:05', '2015-06-26', 500, 'Problema no esner', 'asasd', 1, 4),
(10, 3, 4, '2015-06-21 13:03:16', '0000-00-00', 50, 'asdasdasasd', '', 1, 4),
(13, 3, 2, '2015-06-21 15:57:04', '2015-06-18', 100, 'O computador está lento', '', 1, 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `service_orders_situation`
--

CREATE TABLE IF NOT EXISTS `service_orders_situation` (
`id` int(11) NOT NULL,
  `service_orders_id` int(11) NOT NULL,
  `previous_situations_id` int(11) NOT NULL,
  `actual_situations_id` int(11) NOT NULL,
  `modification_date` datetime NOT NULL,
  `employees_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `situations`
--

CREATE TABLE IF NOT EXISTS `situations` (
`id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `situations`
--

INSERT INTO `situations` (`id`, `name`) VALUES
(1, 'Novo'),
(2, 'Em aberto'),
(3, 'Aprovada'),
(4, 'Concluída'),
(5, 'Reprovada'),
(6, 'Cancelada');

-- --------------------------------------------------------

--
-- Estrutura para tabela `states`
--

CREATE TABLE IF NOT EXISTS `states` (
`id` int(11) NOT NULL,
  `acronym` char(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `states`
--

INSERT INTO `states` (`id`, `acronym`) VALUES
(1, 'AC'),
(2, 'AL'),
(3, 'AP'),
(4, 'AM'),
(5, 'BA'),
(6, 'CE'),
(7, 'DF'),
(8, 'ES'),
(9, 'GO'),
(10, 'MA'),
(11, 'MT'),
(12, 'MS'),
(13, 'MG'),
(14, 'PA'),
(15, 'PB'),
(16, 'PR'),
(17, 'PE'),
(18, 'PI'),
(19, 'RJ'),
(20, 'RN'),
(21, 'RS'),
(22, 'RO'),
(23, 'RR'),
(24, 'SC'),
(25, 'SP'),
(26, 'SE'),
(27, 'TO');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cities`
--
ALTER TABLE `cities`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_cities_states` (`states_id`);

--
-- Índices de tabela `clients`
--
ALTER TABLE `clients`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_clients_cities` (`cities_id`);

--
-- Índices de tabela `employees`
--
ALTER TABLE `employees`
 ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `items_service_order`
--
ALTER TABLE `items_service_order`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_items_service_order_services` (`services_id`), ADD KEY `FK_items_service_order_service_orders` (`service_orders_id`);

--
-- Índices de tabela `juridical_clients`
--
ALTER TABLE `juridical_clients`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_juridical_clients_clients` (`clients_id`);

--
-- Índices de tabela `physical_clients`
--
ALTER TABLE `physical_clients`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_physical_clients_clients` (`clients_id`);

--
-- Índices de tabela `priorities`
--
ALTER TABLE `priorities`
 ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `services`
--
ALTER TABLE `services`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_services_categories` (`categories_id`);

--
-- Índices de tabela `service_orders`
--
ALTER TABLE `service_orders`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_service_orders_clients` (`clients_id`), ADD KEY `FK_service_orders_priorities` (`priorities_id`), ADD KEY `FK_service_orders_situations` (`situations_id`), ADD KEY `FK_service_orders_employees` (`employees_id`);

--
-- Índices de tabela `service_orders_situation`
--
ALTER TABLE `service_orders_situation`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_service_orders_situation_employees` (`employees_id`), ADD KEY `FK_service_orders_situation_service_orders` (`service_orders_id`), ADD KEY `FK_service_orders_situation_previous_situations` (`previous_situations_id`), ADD KEY `FK_service_orders_situation_actual_situations` (`actual_situations_id`);

--
-- Índices de tabela `situations`
--
ALTER TABLE `situations`
 ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `states`
--
ALTER TABLE `states`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT de tabela `cities`
--
ALTER TABLE `cities`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `clients`
--
ALTER TABLE `clients`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `employees`
--
ALTER TABLE `employees`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `items_service_order`
--
ALTER TABLE `items_service_order`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de tabela `juridical_clients`
--
ALTER TABLE `juridical_clients`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `physical_clients`
--
ALTER TABLE `physical_clients`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `priorities`
--
ALTER TABLE `priorities`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `services`
--
ALTER TABLE `services`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `service_orders`
--
ALTER TABLE `service_orders`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de tabela `service_orders_situation`
--
ALTER TABLE `service_orders_situation`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `situations`
--
ALTER TABLE `situations`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `states`
--
ALTER TABLE `states`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `cities`
--
ALTER TABLE `cities`
ADD CONSTRAINT `FK_cities_states` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`);

--
-- Restrições para tabelas `clients`
--
ALTER TABLE `clients`
ADD CONSTRAINT `FK_clients_cities` FOREIGN KEY (`cities_id`) REFERENCES `cities` (`id`);

--
-- Restrições para tabelas `items_service_order`
--
ALTER TABLE `items_service_order`
ADD CONSTRAINT `FK_items_service_order_service_orders` FOREIGN KEY (`service_orders_id`) REFERENCES `service_orders` (`id`),
ADD CONSTRAINT `FK_items_service_order_services` FOREIGN KEY (`services_id`) REFERENCES `services` (`id`);

--
-- Restrições para tabelas `juridical_clients`
--
ALTER TABLE `juridical_clients`
ADD CONSTRAINT `FK_juridical_clients_clients` FOREIGN KEY (`clients_id`) REFERENCES `clients` (`id`);

--
-- Restrições para tabelas `physical_clients`
--
ALTER TABLE `physical_clients`
ADD CONSTRAINT `FK_physical_clients_clients` FOREIGN KEY (`clients_id`) REFERENCES `clients` (`id`);

--
-- Restrições para tabelas `services`
--
ALTER TABLE `services`
ADD CONSTRAINT `FK_services_categories` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`);

--
-- Restrições para tabelas `service_orders`
--
ALTER TABLE `service_orders`
ADD CONSTRAINT `FK_service_orders_clients` FOREIGN KEY (`clients_id`) REFERENCES `clients` (`id`),
ADD CONSTRAINT `FK_service_orders_employees` FOREIGN KEY (`employees_id`) REFERENCES `employees` (`id`),
ADD CONSTRAINT `FK_service_orders_priorities` FOREIGN KEY (`priorities_id`) REFERENCES `priorities` (`id`),
ADD CONSTRAINT `FK_service_orders_situations` FOREIGN KEY (`situations_id`) REFERENCES `situations` (`id`);

--
-- Restrições para tabelas `service_orders_situation`
--
ALTER TABLE `service_orders_situation`
ADD CONSTRAINT `FK_service_orders_situation_actual_situations` FOREIGN KEY (`actual_situations_id`) REFERENCES `situations` (`id`),
ADD CONSTRAINT `FK_service_orders_situation_employees` FOREIGN KEY (`employees_id`) REFERENCES `employees` (`id`),
ADD CONSTRAINT `FK_service_orders_situation_previous_situations` FOREIGN KEY (`previous_situations_id`) REFERENCES `situations` (`id`),
ADD CONSTRAINT `FK_service_orders_situation_service_orders` FOREIGN KEY (`service_orders_id`) REFERENCES `service_orders` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
