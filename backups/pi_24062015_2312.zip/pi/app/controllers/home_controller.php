<?php class HomeController extends ApplicationController {

   public function index() {
      $this->title = 'Projeto Integrador 2015/1';
   }

} ?>
