<?php
  class ModelNotFindException extends Exception {}
  class DatabaseException extends Exception {}
?>
