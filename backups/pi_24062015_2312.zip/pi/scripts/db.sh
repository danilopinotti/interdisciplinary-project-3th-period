#!/bin/bash

db_user='root'
db_pwd='root'

if [ ! -z $1 ] && [ $1 == "reload" ]; then
  mysql -u $db_user -p$db_pwd < db/mysql.sql
  echo "OK"
fi
