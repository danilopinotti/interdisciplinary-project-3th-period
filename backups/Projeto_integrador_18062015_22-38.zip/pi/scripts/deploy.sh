#!/bin/bash

echo "Do as exercise!!"
