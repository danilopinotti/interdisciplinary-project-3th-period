<?php 
class Category extends Base {
	private $name;

	public function getName(){
		return $this->name;
	}

	public function setName($name){
		$this->name = $name;
	}

	public function validates(){
		Validations::greaterThen($this->name, 5, 'name', $this->errors);
		Validations::notEmpty($this->name, 'name', $this->errors);
	}

	public function save(){
		if(!$this->isValid()) return false;
		
		$params = array($this->name, $this->createdAt);
		$sql = "insert into categories (name, created_at) 
		values (?,?)";

		$db = Database::getConnection();
		$statement = $db->prepare($sql);
		$resp = $statement->execute($params);

		if (!$resp) {
			Logger::getInstance()->log("Falha para salvar categoria: " . print_r($this, TRUE), Logger::ERROR);
			Logger::getInstance()->log("Error: " . print_r(error_get_last(), true), Logger::ERROR);
			return false;
		}
		return true;
	}

	public static function all(){
		$sql = "SELECT * FROM categories ORDER BY created_at";
		$db = Database::getConnection();
		$statement = $db->prepare($sql);
		$resp = $statement->execute();

		$categories = [];

		while($resp && $category = $statement->fetch(PDO::FETCH_ASSOC)){
			$categories[] = new Category($category);
		}
		return $categories;

	}


} ?>