<?php class ServicesController extends ApplicationController {

   public function index() {
      $this->title = 'Serviços';
   }

} ?>
