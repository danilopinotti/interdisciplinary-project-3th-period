<?php class SessionsController extends ApplicationController {

   public function logout() {
      $this->title = 'Logout';
   }

   public function login(){
   	  $this->title = 'Login';
   }

   public function autenticate(){
   	
   }

} ?>
