<?php class CategoriesController extends ApplicationController {

   public function index() {
      $this->title = 'Listagem de categorias';
      $this->categories = Category::all();
   }

   public function _new() {
      $this->category = new Category();
   }

   public function create() {
      $this->category = new Category($this->params['category']);
      
      if($this->category->save()){
      	Flash::message('success', 'Categoria Cadastrada com Sucesso!!');
      	$this->redirectTo('/categorias');
      }
      else{
      	Flash::message('danger', 'Existe dados Invalidos!!');
      	$this->render('new');
      }
   }

} ?>
