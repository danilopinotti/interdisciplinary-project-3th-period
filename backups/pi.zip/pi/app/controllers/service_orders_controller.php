<?php class ServiceOrdersController extends ApplicationController {

   public function index() {
      $this->title = 'Ordens de serviços';
   }

} ?>
