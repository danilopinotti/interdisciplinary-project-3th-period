<?php class ClientsController extends ApplicationController {

   public function physical_new() {
      $this->title = 'Cadastro de cliente físico';
   }

   public function physical_create() {
      $this->title = 'Clientes';
   }

   public function juridicial_new() {
      $this->title = 'Cadastro de cliente jurídico';
   }

      public function juridicial_create() {
      $this->title = 'Clientes';
   }

} ?>
