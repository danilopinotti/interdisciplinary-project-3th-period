<?php
    require 'application.php';
    $router = new Router($_SERVER['REQUEST_URI']);

    $router->get('/', array('controller' => 'HomeController', 'action' => 'index'));

    //rotas para categorias

    $router->get('/categorias', array('controller' => 'CategoriesController', 'action' => 'index'));
    $router->get('/categorias/novo', array('controller' => 'CategoriesController', 'action' => '_new'));
    $router->post('/categorias', array('controller' => 'CategoriesController', 'action' => 'create'));

    $router->get('/ordens-servicos', array('controller' => 'ServiceOrdersController', 'action' => 'index'));
    $router->get('/servicos', array('controller' => 'ServicesController', 'action' => 'index'));
	
    $router->get('/clientes/cadastro/fisico', array('controller' => 'ClientsController', 'action' => 'physical_new'));
	$router->get('/clientes/cadastro/juridico', array('controller' => 'ClientsController', 'action' => 'juridicial_new'));
    $router->post('/clientes/cadastro/fisico', array('controller' => 'ClientsController', 'action' => 'physical_create'));
    $router->post('/clientes/cadastro/juridico', array('controller' => 'ClientsController', 'action' => 'juridicial_create'));
    

    $router->get('/relatorios', array('controller' => 'ReportsController', 'action' => 'index'));
    $router->post('/logout', array('controller' => 'SessionsController', 'action' => 'logout'));
    $router->get('/login', array('controller' => 'SessionsController', 'action' => 'login'));
    $router->post('/login', array('controller' => 'SessionsController', 'action' => 'autenticate'));

    $router->load();
?>
