<?php
  /*
   * Configurações de acesso ao banco de dados.
   * */
  $db_host = 'localhost';
  $db_user = 'root';
  $db_pswd = 'root';
  $db_port = '3306';
  $db_dbname = 'projeto_integrador';
?>
